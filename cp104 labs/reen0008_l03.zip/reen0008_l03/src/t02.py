"""
-------------------------------------------------------
Lab 3, Task 2
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-09-27"
-------------------------------------------------------
"""
# Imports


print("""'Twinkle Twinkle Little Star' by Jane Taylor""")
print()
print("Twinkle, twinkle, little star,")
print("    How I wonder what you are!")
print( "       Up above the world so high,")
print( "       Like a diamond in the sky.")
print("Twinkle, twinkle, little star,")
print("    How I wonder what you are!")
