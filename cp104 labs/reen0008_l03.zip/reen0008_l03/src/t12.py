"""
-------------------------------------------------------
Lab 3, Task 12 
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-09-27"
-------------------------------------------------------
"""

first = 100
second = 34
third = 933
total = first + second + third 
print("Values")
print(f"First:  {first:_>6d}")
print(f"Second: {second:_>6d}")
print(f"Third:  {third:_>6d}")
print(f"Total:  {total:_>6d}")
# Imports