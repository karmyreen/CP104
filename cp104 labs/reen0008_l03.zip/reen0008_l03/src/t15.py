"""
-------------------------------------------------------
Lab 3, Task 15
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-09-27"
-------------------------------------------------------
"""
# Imports

integer = 654321
decimal = 654.32
phrase = "Hello World"

print(f"{integer:d}") #works
print(f"{integer:f}") #works, but with alot of zeros 
# print(f"{integer:s}") #doesnt work

#print(f"{decimal:d}") #doesnt work
print(f"{decimal:f}") #works
#print(f"{decimal:s}") #doesnt work


#print(f"{phrase:f}") #doesnt work
#print(f"{phrase:d}") #doesnt work
print(f"{phrase:s}") #works



