"""
-------------------------------------------------------
Lab 3, Task 5 
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-09-27"
-------------------------------------------------------
"""

minimum = int(input("Input the minimum: "))
maximum = int(input("Input the Maximum: "))

difference = maximum - minimum

print(f"The difference between {maximum:d} and {minimum:d} is {difference:d}")
# Imports