"""
-------------------------------------------------------
Lab 5, Task 5
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-16"
-------------------------------------------------------
"""
# Imports

from functions import is_leap
year = int(input("This is the year: "))

print(is_leap(year))