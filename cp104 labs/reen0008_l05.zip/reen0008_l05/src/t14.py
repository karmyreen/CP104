"""
-------------------------------------------------------
Lab 5, Task 14
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-16"
-------------------------------------------------------
"""
# Imports

from functions import ticket

price = ticket()
print(f"${price:.2f}")