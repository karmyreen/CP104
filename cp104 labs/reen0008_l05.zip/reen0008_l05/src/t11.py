"""
-------------------------------------------------------
Lab 5, Task 11 
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-16"
-------------------------------------------------------
"""
# Imports
from functions import quadrant



x_var = float(input("X-value: "))
y_var = float(input("y-value: "))

print(quadrant(x_var,y_var))
