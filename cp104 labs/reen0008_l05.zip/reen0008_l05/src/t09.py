"""
-------------------------------------------------------
Lab 5, Task 9 
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-16"
-------------------------------------------------------
"""
# Imports

from functions import wind_speed
speed_of_wind = int(input("Input wind speeds (km/hr): "))
type_of_wind = wind_speed(speed_of_wind)

print(type_of_wind)