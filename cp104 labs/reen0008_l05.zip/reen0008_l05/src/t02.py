"""
-------------------------------------------------------
Lab 5, Task 2 
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-16"
-------------------------------------------------------
"""
# Imports
from functions import get_weight

mass = float(input(" What is the mass (Kg): "))
weight, message = get_weight(mass)
print(message)
