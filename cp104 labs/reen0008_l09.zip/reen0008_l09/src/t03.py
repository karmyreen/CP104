"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-11-14"
-------------------------------------------------------
"""
# Imports
from functions import parse_code


first, second, third = parse_code('WWE4992W15')

print(f"{first},{second},{third}")