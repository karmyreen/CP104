"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-11-14"
-------------------------------------------------------
"""
# Imports

from functions import str_distance
s1 = "David"
s2 = "David"

distance = str_distance(s1, s2)

print(distance)