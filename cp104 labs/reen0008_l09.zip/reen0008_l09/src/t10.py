"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-11-14"
-------------------------------------------------------
"""
# Imports
from functions import text_analyze
txt = 'AHHH, RUN '
uppr, lwr , digts, whtpc = text_analyze(txt)
print(f"{uppr}, {lwr}, {digts}, {whtpc}")
