"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-30"
-------------------------------------------------------
"""
# Imports
from functions import budget

total, balance, status = budget(1000)

print(f"{total}, {balance}, {status}")

