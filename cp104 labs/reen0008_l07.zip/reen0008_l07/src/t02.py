"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-30"
-------------------------------------------------------
"""
# Imports
from functions import power_of_two


power = power_of_two(6)
print(power)