"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-30"
-------------------------------------------------------
"""
# Import

from functions import positive_statistics

maxi, mini, ave, total = positive_statistics()

print(f"{maxi:.2f}, {mini:.2f}, {ave:.2f}, {total:.2f}")
