"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-30"
-------------------------------------------------------
"""
# Imports

from functions import employee_payroll

total, average = employee_payroll()

print(f"{total:,.2f}, {average:,.2f}")