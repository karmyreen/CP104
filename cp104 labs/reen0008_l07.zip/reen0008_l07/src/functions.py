"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-30"
-------------------------------------------------------
"""
# Imports

from random import randint 



def hi_lo_game(high):
    """
    -------------------------------------------------------
    Plays a random higher-lower guessing game.
    Use: count = hi_lo_game(high)
    -------------------------------------------------------
    Parameters:
        high - maximum random value (int > 1)
    Returns:
        count - the number of guesses the user made (int)
    -------------------------------------------------------
    """
    guess = int(input("Guess: "))
    number = randint( 1, high)
    count = 0 
    
    while guess != number: 
        if guess > number: 
            print("Too high, try again.")
            count = count + 1 
            guess = int(input("Guess: "))
           
        else: 
            print("Too low, try again.")
            count = count + 1 
            guess = int(input("Guess: "))
            
      
    count = count + 1   
    print("Congratulations - good guess!")   
 
    
    return count 



def power_of_two(target):
    """
    -------------------------------------------------------
    Determines the nearest power of 2 greater than or equal to
    a given target.
    Use: power = power_of_two(target)
    -------------------------------------------------------
    Parameters:
        target - value to find nearest power of 2 (int >= 0)
    Returns:
        power - first power of 2 >= target (int)
    -------------------------------------------------------
    """
    n = 0 
    power = 1
    while target > power : 
        power = 2**(n)
        n = n + 1
        
    

    return power
   
        
        
        
        
    
    
    
    
    
    
    
    
    





def positive_statistics():
    """
    -------------------------------------------------------
    Asks a user to enter a series of positive numbers, then calculates
    and returns the minimum, maximum, total, and average of those numbers.
    Stop processing values when the user enters a negative number.
    The first number entered must be positive.
    Use: minimum, maximum, total, average = positive_statistics()
    -------------------------------------------------------
    Returns:
        minimum - smallest of the entered values (float)
        maximum - largest of the entered values (float)
        total - total of the entered values (float)
        average - average of the entered values (float)
    ------------------------------------------------------
    """
    
    maximum = 0
    minimum = 0
    total = 0 
    count = 0 
    number = float(input("Here is the first positive number: "))
    
    while number >= 0 : 
      
        total = total + number
        
        if count == 0: 
            maximum = number 
            minimum = number 
        else: 
            if number > maximum: 
                maximum = number
            if number < minimum: 
                minimum  = number 
            
            
           
        count= count + 1
        number = float(input("Next positive value: "))
        
        
        
    if total == 0 : 
        average = 0 
    else: 
        average = total / count 
        
     
    return  minimum,maximum,total , average
     
    
    
   
def budget(available):
    """
    -------------------------------------------------------
    Asks a user for a series of expenses in a month. Calculate the
    total expenses and determines whether the user is in "Surplus",
    "Deficit", or "Balanced" status.
    Use: expenses, balance, status = budget(available)
    -------------------------------------------------------
    Parameters:
        available - money currently available (float >= 0)
    Returns:
        expenses - total monthly expenses (float)
        balance - remaining balance (float)
        status - One of (str):
            "Surplus" if user budget is in surplus
            "Deficit" if user budget is in deficit
            "Balanced" if user budget is balanced
    ------------------------------------------------------
    """
    
    expenses = float(input("Enter a expense ( 0 to quit): "))
    total = 0 
    
    while expenses != 0 : 
        total = total + expenses
        available = available - expenses 
        expenses = float(input("Enter another expense (0 to quit):"))
        
    balance = available
    if balance < 0 : 
        status  = 'Deficit'
    elif balance == 0 : 
        status = 'Balanced'
    else :
        status = 'Surplus'
    
    return total, balance ,status





def employee_payroll():
    """
    -------------------------------------------------------
    Calculates and returns the weekly employee payroll for all employees
    in an organization. For each employee, ask the user for the employee ID
    number, the hourly wage rate, and the number of hours worked during a week.
    An employee number of zero indicates the end of user input.
    Each employee is paid 1.5 times their regular hourly rate for all hours
    over 40. A tax amount of 3.625 percent of gross salary is deducted.
    Use: total, average = employee_payroll()
    -------------------------------------------------------
    Returns:
        total - total net employee wages (i.e. after taxes) (float)
        average - average employee net wages (float)
    ------------------------------------------------------
    """
    OVERTIME_RATE= 1.5
    TAX_RATE = 3.625
    OVERTIME = 40 
    
    
    employ_id = int(input("Employee ID:"))
    count = 0 
    total = 0 
    
    
    
    while  employ_id != 0 : 
        count = count + 1
        hour_wage = float(input("Hourly wage rate: "))
        hours_worked = float(input("Hours worked: "))
        
        if hours_worked > OVERTIME : 
            over_new_wage = hour_wage * (OVERTIME_RATE)
            after_40 =  over_new_wage * (hours_worked - OVERTIME)
            before_40 = hour_wage * OVERTIME 
            with_out_tax =  after_40 + before_40
        if hours_worked < OVERTIME:  
            with_out_tax = hour_wage * hours_worked
        #if hours_worked < OVERTIME : 
            #hour_wage 
            
        
       
        final = with_out_tax - (with_out_tax * (TAX_RATE/ 100))
        total = total + final 
        employ_id = int(input("Employee ID:"))
    
    
    average = total / count 
    
    return total , average 
                               
                               
    
        
        
        
        
        
    
    