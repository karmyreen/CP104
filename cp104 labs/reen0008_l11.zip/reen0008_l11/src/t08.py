"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-11-28"
-------------------------------------------------------
"""
# Imports
from functions import find_less 

result = find_less([[4, 5.5, 7.25], [2, 9.3, 0.9]],2.2 )

print(result)
