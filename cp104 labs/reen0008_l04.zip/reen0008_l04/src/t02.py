"""
-------------------------------------------------------
Lab 4 , Task 2 
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-03"
-------------------------------------------------------
"""

from functions import circumference
radius = float(input("The radius of the circle: "))
answer = circumference(radius)
print(f"Result in (cm): {answer:0.2f}")


# Imports