"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-09-19"
-------------------------------------------------------
"""

charge = float(input("Food Charge: ($)"))
sales_tax = float(input("Sales tax in (%): "))
tip = float(input("Tip in (%): "))


tax = sales_tax /100
tip2 = tip/ 100


final_tax = charge * tax
final_tip = charge * tip2

grand_total = charge + final_tax + final_tip 

print("Here is the cost of food: ", charge)
print()
print("Here is tax: ",  final_tax)
print()
print("Here is tip: $" , final_tip)
print()
print("Here is last cost: $", grand_total)


# Imports