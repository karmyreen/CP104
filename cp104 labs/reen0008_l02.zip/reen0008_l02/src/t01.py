"""
-------------------------------------------------------
[lab 2, Task 1 ]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-09-19"
-------------------------------------------------------
"""

Celcius = int(input(" Temperature in C: "))
F_CONSTANT = 32
temp_f = (9/5 * Celcius + F_CONSTANT)

print("The temperature in Fahrenheit: " , temp_f)
# Imports