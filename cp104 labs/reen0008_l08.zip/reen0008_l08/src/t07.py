"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-11-07"
-------------------------------------------------------
"""
# Imports
from functions import list_categorize

negatives, positives, zeros, evens , odds = list_categorize([93, 11, 22, -9, -28, 10, 50, 61, 24, 32])

print(f"({negatives}, {positives}, {zeros}, {evens}, {odds})")