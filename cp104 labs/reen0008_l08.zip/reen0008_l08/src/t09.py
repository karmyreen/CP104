"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-11-07"
-------------------------------------------------------
"""
# Imports
from functions import many_search
I = [2,4, 5, 7, 9,2]
J = [94, 96, -22, -79, -28, 96, -50, 71, 24, -32]

indexes = many_search( I,7)

print(indexes)