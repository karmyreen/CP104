"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-09-27"
-------------------------------------------------------
"""

leng_inches = int(input("Length in inches: ")) 

CONVERSION_UNIT = 0.0254

formula = leng_inches * CONVERSION_UNIT

print(f"The length meters:{formula}")
# Imports