"""
-------------------------------------------------------
Assignment 1 , Task 2
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-09-27"
-------------------------------------------------------
"""
# Imports
fav_food = str(input("Enter your favourite Food: "))
fav_show= str(input("Enter your favourite Tv Show: "))

print(f"I like to eat {fav_food:s} while watching {fav_show:s}")
