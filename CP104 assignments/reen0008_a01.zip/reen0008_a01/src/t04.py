"""
-------------------------------------------------------
Assignment 1, Task 4
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-09-27"
-------------------------------------------------------
"""
# Imports

cost_one = float(input("Cost of 1 pizza slice: $"))
num_of_slices = int(input("Number of pizza slices: "))

total_cost = cost_one * num_of_slices 

print(f"The total cost of {num_of_slices} is ${total_cost}")