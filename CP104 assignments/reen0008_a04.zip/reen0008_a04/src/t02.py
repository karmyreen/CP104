"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-29"
-------------------------------------------------------
"""
# Imports
from functions import pollution_level

number = float(input("Input number here: "))

level = pollution_level(number)

print(level)