"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-10-29"
-------------------------------------------------------
"""

from functions import day_of_week



day = day_of_week(9)

print(day)



