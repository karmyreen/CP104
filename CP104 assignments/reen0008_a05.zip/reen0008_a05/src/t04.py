"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-11-03"
-------------------------------------------------------
"""
# Imports
from functions import multiplication_table

multiplication_table(1, 3)

