"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-11-16"
-------------------------------------------------------
"""
# Imports
from functions import subtract_lists

minu = [7,3,7,5,4,7,8,9,7]
sub = [9,7]
subtract_lists(minu, sub)
print(minu)