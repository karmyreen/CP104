"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-11-16"
-------------------------------------------------------
"""
# Imports
from functions import list_indexes 

answer = list_indexes([4,5,3,4,4,7,7,4,-1], 4 )

print(answer)