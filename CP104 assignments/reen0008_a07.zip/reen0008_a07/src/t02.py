"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-11-16"
-------------------------------------------------------
"""
# Imports
from functions import list_positives

answer = list_positives()

print(answer)