"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Gurkarman Reen
ID:      169030008
Email:   reen0008@mylaurier.ca
__updated__ = "2022-11-23"
-------------------------------------------------------
"""
# Imports
from functions import add_spaces
string_input = str(input("What string do you want to input: "))
answer = add_spaces(string_input)

print(answer)